# Capsi Burger — site vitrine

Site statique : un seul `index.html` (HTML, CSS et JS inclus) et deux dossiers.

- `index.html` : la page
- `media/` : vidéo `capsi.mp4` (muette, en boucle) et image `poster.jpg`
- `img/` : logo et photos (façade, salle)

## Mettre en ligne (GitHub Pages)
1. Crée un dépôt et mets-y ces fichiers à la racine.
2. Settings > Pages > branche `main`, dossier `/ (root)`.
3. Le site est servi à `https://<ton-compte>.github.io/<dépôt>/`.

## À modifier
- Menu : tableau `MENU` dans la balise `<script>` en bas de `index.html`.
- Numéros WhatsApp : liens `https://wa.me/221...` dans la section `#commander` et `#infos`.
- Thème : variables CSS en haut de `index.html` (`:root`), thème sombre dans les deux blocs `dark`.
- Carte : l'iframe Google Maps de la section `#infos` (coordonnées dans `q=`).
